<?php
session_start();

$stuid=$_SESSION["stuid"];

$conn = new mysqli("localhost", "root", "","drreddy");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$name=$_POST["name"];
$contact=$_POST["contact"];
$rname=$_POST["rname"];
$comment=$_POST["comment/about"];
$state=$_POST["state"];
$sql = "insert into feedback(name,contact,enhancements,comment,state) values('$name','$contact','$rname','$comment','$state')";

$res=$conn->query($sql);
header("location:index.php");
?>