<html>
<head>
        <body background="book.jpg">
    <link rel="stylesheet" href="main.css"/>

</html>
<?php
echo "<h1> Course Contents</h1>";
$dir = "uploded files\\";
// Sort in ascending order - this is default
$a = scandir($dir);
// Sort in descending order
$b = scandir($dir,1);
foreach($a as $i)
{
if($i== '.' || $i== '..')
continue;
echo "<br>";
echo "<center>";
echo "<h2><a href='$dir$i'>$i</a><br></h2>";
echo "</center>";
}
?>