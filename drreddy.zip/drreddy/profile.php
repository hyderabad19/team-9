<head>
  <body background="book.jpg">
    <link rel="stylesheet" href="main.css"/>
<div class="login">
  <h1>Your Profile</h1>
  <form method="post" action="">
<?php
session_start();
$stuid=$_SESSION["stuid"];
$conn = new mysqli("localhost", "root", "","drreddy");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$sql = "select * from student where stu_id='$stuid'";

$res=$conn->query($sql);

    while($row=$res->fetch_assoc())
    {
      
    echo '<p><input type="text" name="FirstName" value="" placeholder='.$row['stu_name'].'></p>';
    echo '<p><input type="text" name="FatherName" value="" placeholder='.$row['skills'].'></p>';
    echo '<p><input type="date" name="DD-MM-YYYY" value="" placeholder='.$row['dob'].'></p>';
    echo '<p><input type="text" name="Phno" value="" placeholder='.$row['phno'].'></p>';
    echo '<p><textarea row="5" cols="25" name="Address" value="" placeholder="Address">'.$row['addr'].'</textarea></p>';
    }

   
  ?>    

  
    

    
    
    <p class="submit"><input type="submit" name="commit" value="Update"></p>
  </form>
</div>

<div class="login-help">
  <p>Reset <a href="#">Click here to reset it</a>.</p>
</div>