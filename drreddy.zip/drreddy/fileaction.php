<?php  
$target_path = "uploded files\\";  
$target_path = $target_path.basename( $_FILES['file']['name']);   
  
if(move_uploaded_file($_FILES['file']['tmp_name'], $target_path)) {  
	echo $target_path;
    header("location:index.php");
} 
?>
