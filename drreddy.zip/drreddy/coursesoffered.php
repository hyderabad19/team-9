<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="main.css"/>
</head>
<body>
<body bgcolor=black>
                  <link rel="stylesheet" href="main.css"/>
<div class="container">
  <h2>Dropdowns</h2>
  <!--<p>The .dropdown class is used to indicate a dropdown menu.</p>
  <p>Use the .dropdown-menu class to actually build the dropdown menu.</p>
  <p>To open the dropdown menu, use a button or a link with a class of .dropdown-toggle and data-toggle="dropdown".</p>                                     -->     
  


<?php
session_start();
$staid=$_SESSION["staid"];
$conn = new mysqli("localhost", "root", "","drreddy");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$sql = "select * from course where course_id IN (select course_id from sta_cou_bridge where sta_id=$staid)";

$res=$conn->query($sql);
echo '<div class="dropdown">';
        echo '<button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Dropdown Example';
        echo '<span class="caret"></span></button>';
        echo '<ul class="dropdown-menu">';

    while($row=$res->fetch_assoc())
    {
        
          echo '<li><a href="htmlcourse.html">'.$row['course_name'].'</a></li>';
          
        
             
    }

    echo '</ul>';
    echo '</div>'; 
  ?> 
  </div>  
