<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  
</head>

<body background="book.jpg">
                  <link rel="stylesheet" href="main.css"/>
              <div class="login">
<div class="container">
  <h2>Dropdowns</h2>
  <!--<p>The .dropdown class is used to indicate a dropdown menu.</p>
  <p>Use the .dropdown-menu class to actually build the dropdown menu.</p>
  <p>To open the dropdown menu, use a button or a link with a class of .dropdown-toggle and data-toggle="dropdown".</p>                                     -->     
  

<?php
session_start();
$stuid=$_SESSION["stuid"];

$conn = new mysqli("localhost", "root", "","drreddy");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$sql = "select * from course where course_id IN (select course_id from stu_sta_cou_bridge where stu_id=$stuid)";

echo '<div class="dropdown">';
        echo '<button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Courses';
        echo '<span class="caret"></span></button>';
        echo '<ul class="dropdown-menu">';

    //while($row=$res->fetch_assoc())
    //{
        
          //echo '<li><a href="display.php">'.$row['course_name'].'</a></li>';
          echo '<li><a href="display.php">"HTML"</a></li>';
          echo '<li><a href="display.php">"css"</a></li>';
          echo '<li><a href="display.php">"AJAX"</a></li>';
          
        
             
    //}

    echo '</ul>';
    echo '</div>';

   
  ?>    
  </div>